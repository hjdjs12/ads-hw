#include "compressed_radix_tree.hpp"
#include <iostream>
#include <cmath>
CompressedRadixTree::CompressedRadixTree()
{
    root = new CompressedRadixNode(nullptr, 1, 0, 0);
}

CompressedRadixTree::~CompressedRadixTree()
{
    // To Be Implemented
}

void CompressedRadixTree::insert(int32_t value)
{
    if (find(value))
    {
        return;
    }
    int8_t *totalValue = new int8_t[16];
    for (int i = 0; i < 16; i++)
    {
        totalValue[i] = (value >> (15 - i) * 2) & 0x3;
    }
    insertHelp(root, totalValue, 0, 2);
}

void CompressedRadixTree::insertHelp(CompressedRadixNode *node, int8_t *totalValue, int index, int height)
{
    int childIndex = totalValue[index];
    if (node->child[childIndex] == nullptr)
    { // 直接将剩余所有的bit组合成一个节点
        node->child[childIndex] = new CompressedRadixNode(node, height, 16 - index, childIndex);
        CompressedRadixNode *tmp = node->child[childIndex];
        tmp->value = new int8_t[16 - index];
        for (int i = 0; i < 16 - index; i++)
        {
            tmp->value[i] = totalValue[index + i];
        }
    }
    else
    {
        bool isFullyFixed = true;
        int splitIndex = 0;
        CompressedRadixNode *tmp = node->child[childIndex];
        for (int i = 0; i < tmp->bitLength; i++)
        {
            if (tmp->value[i] != totalValue[index + i])
            {
                isFullyFixed = false;
                splitIndex = i;
                break;
            }
        }
        if (isFullyFixed)
        {
            insertHelp(tmp, totalValue, index + tmp->bitLength, ++height);
        }
        else
        {
            int8_t *sharedPart = new int8_t[splitIndex];
            for (int i = 0; i < splitIndex; i++)
            {
                sharedPart[i] = tmp->value[i];
            }
            int8_t *prePart = new int8_t[tmp->bitLength - splitIndex];
            for (int i = splitIndex; i < tmp->bitLength; i++)
            {
                prePart[i - splitIndex] = tmp->value[i];
            }
            int8_t *newPart = new int8_t[16 - index - splitIndex];
            for (int i = splitIndex; i < 16 - index; i++)
            {
                newPart[i - splitIndex] = totalValue[index + i];
            }

            CompressedRadixNode *shared = new CompressedRadixNode(tmp->parent, height, splitIndex, tmp->indexInParent);
            tmp->parent->child[tmp->indexInParent] = shared;
            shared->value = sharedPart;

            CompressedRadixNode *newNode = new CompressedRadixNode(shared, height + 1, 16 - index - splitIndex, newPart[0]);
            shared->child[newPart[0]] = newNode;
            newNode->value = newPart;

            tmp->bitLength = tmp->bitLength - splitIndex;
            delete[] tmp->value;
            tmp->value = prePart;
            tmp->height += 1;
            tmp->parent = shared;
            tmp->indexInParent = prePart[0];
            shared->child[prePart[0]] = tmp;
        }
    }
}

void CompressedRadixTree::remove(int32_t value)
{

    if (!find(value))
    {
        return;
    }
    else
    {
        int8_t *totalValue = new int8_t[16];
        for (int i = 0; i < 16; i++)
        {
            totalValue[i] = (value >> (15 - i) * 2) & 0x3;
        }
        CompressedRadixNode *tmp = root;
        for (int i = 0; i < 16;)
        {
            tmp = tmp->child[totalValue[i]];
            i += tmp->bitLength;
        }
        removeHelp(tmp);
    }
}
void CompressedRadixTree::removeHelp(CompressedRadixNode *node)
{
    if (node == root)
    {
        return;
    }
    CompressedRadixNode *p = node->parent;
    p->child[node->indexInParent] = nullptr;
    delete node;
    node = nullptr;
    int childOfParentNumber = 0;
    for (int i = 0; i < 4; i++)
    {
        if (p->child[i] != nullptr)
        {
            childOfParentNumber++;
        }
    }
    if (childOfParentNumber == 0)
    {
        removeHelp(p);
    }
    else if (childOfParentNumber == 1)
    {

        removeMerge(p);
    }
    return;
}
void CompressedRadixTree::removeMerge(CompressedRadixNode *node)
{
    if (node == root)
    {
        return;
    }

    int index = 0;
    for (int i = 0; i < 4; i++)
    {
        if (node->child[i] != nullptr)
        {
            index = i;
            break;
        }
    }
    CompressedRadixNode *tmp = node->child[index];
    int8_t *newMergeValue = new int8_t[node->bitLength + tmp->bitLength];
    for (int i = 0; i < node->bitLength; i++)
    {
        newMergeValue[i] = node->value[i];
    }
    for (int i = 0; i < tmp->bitLength; i++)
    {
        newMergeValue[i + node->bitLength] = tmp->value[i];
    }
    tmp->bitLength = node->bitLength + tmp->bitLength;
    delete tmp->value;
    tmp->value = newMergeValue;
    tmp->indexInParent = node->indexInParent;
    tmp->height -= 1;
    tmp->parent = node->parent;
    node->parent->child[node->indexInParent] = tmp;
    delete node;
    return;
}

bool CompressedRadixTree::find(int32_t value)
{
    int8_t *totalValue = new int8_t[16];
    for (int i = 0; i < 16; i++)
    {
        totalValue[i] = (value >> (15 - i) * 2) & 0x3;
    }
    return findHelp(root, totalValue, 0);
}
bool CompressedRadixTree::findHelp(CompressedRadixNode *node, int8_t *totalValue, int index)
{
    int childIndex = totalValue[index];
    CompressedRadixNode *tmp = node->child[childIndex];
    if (tmp == nullptr)
    {
        return false;
    }
    int length = tmp->bitLength;
    for (int i = 0; i < length; i++)
    {
        if (tmp->value[i] != totalValue[index + i])
        {
            return false;
        }
    }
    if (index + tmp->bitLength == 16)
    {
        return true;
    }
    else
        return findHelp(tmp, totalValue, index + tmp->bitLength);
}

uint32_t CompressedRadixTree::size()
{
    return 1 + sizeHelp(root);
}

uint32_t CompressedRadixTree::sizeHelp(CompressedRadixNode *node)
{
    uint32_t sum = 0;
    if (node == nullptr)
    {
        return 0;
    }
    for (int i = 0; i < 4; i++)
    {
        if (node->child[i] != nullptr)
        {
            sum = sum + 1 + sizeHelp(node->child[i]);
        }
    }
    return sum;
}
uint32_t CompressedRadixTree::height()
{
    return heightHelp(root);
}
uint32_t CompressedRadixTree::heightHelp(CompressedRadixNode *node)
{
    if (node == nullptr)
    {
        return 0;
    }
    uint32_t maxHeight = 0;
    for (int i = 0; i < 4; i++)
    {
        if (heightHelp(node->child[i]) > maxHeight)
        {
            maxHeight = heightHelp(node->child[i]);
        }
    }
    return maxHeight + 1;
}
