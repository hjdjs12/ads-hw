// implement a radix tree that support node compressino and store int32_t values
// each parent node has 4 children, representing 2 bits
#include <cstdint>
#include <algorithm>
#include "tree.hpp"
struct CompressedRadixNode
{
    int bitLength;
    int8_t *value;
    int indexInParent;
    int height;
    CompressedRadixNode *parent;
    CompressedRadixNode *child[4];
    CompressedRadixNode(CompressedRadixNode *p, int h, int l, int inParent) : parent(p), height(h), bitLength(l), indexInParent(inParent)
    {
        for (int i = 0; i < 4; i++)
        {
            child[i] = nullptr;
        }
    }
};

class CompressedRadixTree : public Tree
{
    // To Be Implemented
public:
    CompressedRadixNode *root;
    CompressedRadixTree();
    ~CompressedRadixTree();
    // basic operation
    void insert(int32_t value);
    void insertHelp(CompressedRadixNode *node, int8_t *totalValue, int index, int height);
    void remove(int32_t value);
    void removeHelp(CompressedRadixNode *node);
    void removeMerge(CompressedRadixNode *node);
    bool find(int32_t value);
    bool findHelp(CompressedRadixNode *node, int8_t *totalValue, int index);
    // statistics
    uint32_t size();
    uint32_t sizeHelp(CompressedRadixNode *node);
    uint32_t height();
    uint32_t heightHelp(CompressedRadixNode *node);
};