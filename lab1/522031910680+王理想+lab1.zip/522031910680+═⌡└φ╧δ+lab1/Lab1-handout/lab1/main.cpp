#include "radix_tree.hpp"
#include "compressed_radix_tree.hpp"
#include <cstring>
#include <fstream>
#include <iostream>
#include<random>
#include <cstdlib>
#include <ctime> 
#include <chrono>
#include "util.hpp"
#include<vector>
#include <algorithm> 
#include"rbtree.hpp"
#include"RBTree.hpp"
// input file format:
// n
// op1 v1
// ...
// opn vn

// output file format:
// result1
// ...
// resultn
void testTree(const char *input, const char *output, TreeType treeType)
{
    Tree* tree;
    switch (treeType)
    {
    case TreeType::RadixTree:
        tree = new class RadixTree();
        break;
    case TreeType::CompressedRadixTree:
        tree = new class CompressedRadixTree();
        break;
    default:
        break;
    }
    std::ifstream ifs(input);
    std::ofstream ofs(output);
    int n;
    ifs >> n;
    for (int i = 0; i < n; i++)
    {
        char op[10];
        int value;
        ifs >> op;
        if (strcmp(op, "print") != 0)
        {
            ifs >> value;
        }
        if (strcmp(op, "insert") == 0)
        {
            tree->insert(value);
        }
        else if (strcmp(op, "remove") == 0)
        {
            tree->remove(value);
        }
        else if (strcmp(op, "find") == 0)
        {
            ofs << (tree->find(value) ? "True" : "False") << std::endl;
        }
        else if (strcmp(op, "print") == 0)
        {
            ofs << tree->size() << " " << tree->height() << std::endl;
        }
    }
}

// argv[1]: input file path
// argv[2]: output file path
// argv[3]: tree type
// int main(int argc, char **argv)
// {
//     if (argc != 4)
//     {
//         std::cout << "[usage]: ./main [input_file_path] [output_file_path] [tree_type]" << std::endl;
//         return 0;
//     }
//     TreeType treeType;
//     if (strcmp(argv[3], "RadixTree") == 0) {
//         treeType = TreeType::RadixTree;
//     } else if (strcmp(argv[3], "CompressedRadixTree") == 0) {
//         treeType = TreeType::CompressedRadixTree;
//     }
//     testTree(argv[1], argv[2], treeType);
//     return 0;
// /home/os/Desktop/Lab1-handout// }
int main(int argc, char **argv){
    srand(static_cast<int>(time(nullptr)));
    // Tree *tree = new class RadixTree();
    RBTree  <int32_t> *tree  = new RBTree<int32_t>;
    for(int i = 0; i < 1000; i++){
        int32_t random = rand();
        tree->insert(random);
    }
    std::vector<double> latency;
    for(int i = 0; i < 20000000; i++){
        int randomNumber = rand() % 20;
            if(randomNumber < 10){
                auto start1 = std::chrono::high_resolution_clock::now();
                tree->find(zipf());
                auto end1 = std::chrono::high_resolution_clock::now();
                std::chrono::duration<double> elapsed_seconds = end1 - start1;
                latency.push_back(elapsed_seconds.count());
            }
            // else if(randomNumber < 15){
            //    auto start1 = std::chrono::high_resolution_clock::now();
            //     tree->remove(zipf());
            //     auto end1 = std::chrono::high_resolution_clock::now();
            //     std::chrono::duration<double> elapsed_seconds = end1 - start1;
            //     latency.push_back(elapsed_seconds.count());
            // }
            else{
                auto start1 = std::chrono::high_resolution_clock::now();
                tree->insert(zipf());
                auto end1 = std::chrono::high_resolution_clock::now();
                std::chrono::duration<double> elapsed_seconds = end1 - start1;
                latency.push_back(elapsed_seconds.count());
            }
    }
    std::sort(latency.begin(),latency.end());
    double sum = 0;
    for(int i = 0; i < 20000000 ; i++){
        sum += latency[i];
    }
    std::cout << sum/20000000 << " " <<latency[10000000] << latency[15000000] << " "<< latency[19800000]  << std::endl;
}