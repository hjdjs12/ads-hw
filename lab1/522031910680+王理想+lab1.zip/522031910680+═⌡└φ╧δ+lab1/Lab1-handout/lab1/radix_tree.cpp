#include "radix_tree.hpp"
#include <iostream>
RadixTree::RadixTree()
{
    root = new RadixNode(1, nullptr);
}

RadixTree::~RadixTree()
{
    // To Be Implemented
}

void RadixTree::insert(int32_t value)
{
    int8_t *totalValue = new int8_t[16];
    for (int i = 0; i < 16; i++)
    {
        totalValue[i] = (value >> (15 - i) * 2) & 0x3;
    }
    insertHelp(root, totalValue, 2);
}

void RadixTree::insertHelp(RadixNode *node, int8_t *restValue, int height)
{

    if (!isExistChildNode(node, restValue[0])) // 不存在子节点
    {
        node->child[restValue[0]] = new RadixNode(height, node);
    }
    if (height == 17) // 最底层，不再嵌套
    {
        return;
    }
    insertHelp(node->child[restValue[0]], restValue + 1, ++height);
    return;
}

bool RadixTree::isExistChildNode(RadixNode *node, int8_t value)
{
    if (node->child[value] != nullptr)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void RadixTree::remove(int32_t value)
{
    if (!find(value))
    {
        return;
    }
    else
    {
        int8_t *totalValue = new int8_t[16];
        for (int i = 0; i < 16; i++)
        {
            totalValue[i] = (value >> (15 - i) * 2) & 0x3;
        }
        RadixNode *tmp = root;
        for (int i = 0; i < 16; i++)
        {
            tmp = tmp->child[totalValue[0]];
            if (i != 15)
            {
                totalValue++;
            }
        }
        removeHelp(tmp);
    }
}

void RadixTree::removeHelp(RadixNode *node)
{
    RadixNode *p = node->parent;
    for (int i = 0; i < 4; i++)
    {
        if (p->child[i] == node)
        {
            p->child[i] = nullptr;
        }
    }
    delete node;
    node = nullptr;
    for (int i = 0; i < 4; i++)
    {
        if (p->child[i] != nullptr)
        {
            return;
        }
    }
    if (p->height != 1)
    {
        removeHelp(p);
    }
}

bool RadixTree::find(int32_t value)
{
    int8_t *totalValue = new int8_t[16];
    for (int i = 0; i < 16; i++)
    {
        totalValue[i] = (value >> (15 - i) * 2) & 0x3;
    }
    return findHelp(root, totalValue, 2);
    return true;
}
bool RadixTree::findHelp(RadixNode *node, int8_t *restValue, int height)
{
    if (node->child[restValue[0]] != nullptr)
    {
        if (height == 17)
        {
            return true;
        }
        else
        {
            return findHelp(node->child[restValue[0]], restValue + 1, ++height);
        }
    }
    else
    {
        return false;
    }
}

uint32_t RadixTree::size()
{
    return 1 + sizeHelp(root);
}
uint32_t RadixTree::sizeHelp(RadixNode *node)
{
    uint32_t sum = 0;
    if (node == nullptr)
    {
        return 0;
    }
    for (int i = 0; i < 4; i++)
    {
        if (node->child[i] != nullptr)
        {
            sum = sum + 1 + sizeHelp(node->child[i]);
        }
    }
    return sum;
}
uint32_t RadixTree::height()
{
    bool isEmpty = true;
    for (int i = 0; i < 4; i++)
    {
        if (root->child[i] != nullptr)
        {
            isEmpty = false;
            break;
        }
    }
    if (!isEmpty)
    {
        return 17;
    }
    else
    {
        return 1;
    }
}
