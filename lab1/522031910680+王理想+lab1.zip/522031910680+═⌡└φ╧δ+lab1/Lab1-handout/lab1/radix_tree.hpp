
#include <cstdint>
#include "tree.hpp"
struct RadixNode
{
    RadixNode *child[4];
    RadixNode *parent;
    int height; // 根节点高度为1
    RadixNode(int h, RadixNode *p) : height(h), parent(p)
    {
        for (int i = 0; i < 4; i++)
        {
            child[i] = nullptr;
        }
    }
};
class RadixTree : public Tree
{
    // To Be Implemented
public:
    RadixNode *root;
    RadixTree();
    ~RadixTree();
    // basic operation
    void insert(int32_t value);
    void insertHelp(RadixNode *node, int8_t *restValue, int height); // 要插入的子节点的父节点，要插入的数据，要插入的子节点高度
    bool isExistChildNode(RadixNode *node, int8_t value);
    void remove(int32_t value);
    bool find(int32_t value);
    bool findHelp(RadixNode *node, int8_t *restValue, int height);
    void removeHelp(RadixNode *node); // 要删除的节点
    // statistics
    uint32_t size();
    uint32_t sizeHelp(RadixNode *node);
    uint32_t height();
};
